/* tab_style.css */
QWidget {
    background-color: #3a3a3a;
    color: #ffffff;
    font-family: "Segoe UI", Arial, sans-serif;
}

QLabel {
    color: #ffffff;
}

QLineEdit {
    background-color: #4a4a4a;
    color: #ffffff;
    border: 1px solid #5a5a5a;
    padding: 5px;
    border-radius: 5px;
}

QLineEdit:focus {
    border: 1px solid #6a6a6a;
}

QCheckBox {
    color: #ffffff;
}

QCheckBox::indicator {
    width: 18px;
    height: 18px;
}

QCheckBox::indicator:unchecked {
    image: url(:/icons/unchecked.png);
}

QCheckBox::indicator:checked {
    image: url(:/icons/checked.png);
}

QComboBox {
    background-color: #4a4a4a;
    color: #ffffff;
    border: 1px solid #5a5a5a;
    padding: 5px;
    border-radius: 5px;
}

QComboBox::drop-down {
    subcontrol-origin: padding;
    subcontrol-position: top right;
    width: 20px;
    border-left-width: 1px;
    border-left-color: #5a5a5a;
    border-left-style: solid;
    border-top-right-radius: 3px;
    border-bottom-right-radius: 3px;
}

QComboBox::down-arrow {
    image: url(:/icons/down_arrow.png);
    width: 16px;
    height: 16px;
}

QProgressBar {
    background-color: #4a4a4a;
    color: #ffffff;
    border: 1px solid #5a5a5a;
    border-radius: 5px;
    text-align: center;
}

QProgressBar::chunk {
    background-color: #6a6a6a;
    width: 20px;
    margin: 0.5px;
}