from PyQt5.QtWidgets import QMainWindow, QAction, QTabWidget, QVBoxLayout, QWidget
from target_tab import TargetTab
from exploit_tab import ExploitTab
from control_tab import ControlTab

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("ShadowHunter")
        self.setGeometry(100, 100, 800, 600)

        # Create tabs
        self.tabs = QTabWidget()
        self.setCentralWidget(self.tabs)

        # Add tabs
        self.target_tab = TargetTab()
        self.exploit_tab = ExploitTab()
        self.control_tab = ControlTab()

        self.tabs.addTab(self.target_tab, "Target Discovery")
        self.tabs.addTab(self.exploit_tab, "Exploit Discovery")
        self.tabs.addTab(self.control_tab, "System Control")

        # Menu bar
        self.init_menu()

    def init_menu(self):
        menu_bar = self.menuBar()

        file_menu = menu_bar.addMenu("File")
        exit_action = QAction("Exit", self)
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)

if __name__ == "__main__":
    import sys
    from PyQt5.QtWidgets import QApplication
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())