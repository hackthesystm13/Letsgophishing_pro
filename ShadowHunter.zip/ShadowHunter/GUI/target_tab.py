from PyQt5.QtWidgets import QWidget, QVBoxLayout, QPushButton, QListWidget
from core.target_discovery import discover_targets, phishing_attack

class TargetTab(QWidget):
    def __init__(self):
        super().__init__()
        layout = QVBoxLayout()

        self.target_list = QListWidget()
        layout.addWidget(self.target_list)

        discover_button = QPushButton("Discover Targets")
        discover_button.clicked.connect(self.discover_targets)
        layout.addWidget(discover_button)

        phishing_button = QPushButton("Phishing Attack")
        phishing_button.clicked.connect(self.phishing_attack)
        layout.addWidget(phishing_button)

        self.setLayout(layout)

    def discover_targets(self):
        targets = discover_targets()
        self.target_list.clear()
        for target in targets:
            self.target_list.addItem(f"{target['ip']} - {target['os']}")

    def phishing_attack(self):
        selected_items = self.target_list.selectedItems()
        if selected_items:
            target_ip = selected_items[0].text().split(" - ")[0]
            phishing_attack(target_ip)