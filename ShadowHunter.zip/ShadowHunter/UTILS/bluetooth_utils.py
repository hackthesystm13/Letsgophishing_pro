import bluetooth

def discover_bluetooth_devices():
    nearby_devices = bluetooth.discover_devices(lookup_names=True)
    return nearby_devices