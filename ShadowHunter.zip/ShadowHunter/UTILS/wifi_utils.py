import subprocess

def scan_wifi_networks():
    result = subprocess.run(['iwlist', 'wlan0', 'scan'], capture_output=True, text=True)
    return result.stdout