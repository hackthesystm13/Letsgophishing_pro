import sys
from PyQt5.QtWidgets import QApplication
from gui.main_window import MainWindow
from gui.resources import resources_rc  # Import the compiled resources

def apply_styles():
    # Apply main style
    file = QFile(":/styles/main_style.css")
    file.open(QFile.ReadOnly | QFile.Text)
    stream = QTextStream(file)
    app.setStyleSheet(stream.readAll())

    # Apply tab style
    file = QFile(":/styles/tab_style.css")
    file.open(QFile.ReadOnly | QFile.Text)
    stream = QTextStream(file)
    app.setStyleSheet(stream.readAll())

def main():
    global app
    app = QApplication(sys.argv)
    apply_styles()
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()